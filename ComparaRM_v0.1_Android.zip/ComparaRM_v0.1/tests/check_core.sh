#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
javac -encoding UTF-8 -d "$TMP" app/src/main/java/cl/compararm/app/core/Catalog.java tests/CoreCheck.java
java -ea -Dfile.encoding=UTF-8 -cp "$TMP" CoreCheck
