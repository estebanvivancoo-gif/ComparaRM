import cl.compararm.app.core.Catalog;
import java.util.*;
public class CoreCheck {
    public static void main(String[] args) {
        List<Catalog.Product> p=Catalog.demoProducts();
        assert p.size()==8;
        assert "AZUCAR".equals(Catalog.normalize("Azúcar"));
        assert Catalog.suggestFromOcr("LECHE ENTERA",p).id.equals("demo-leche");
        assert Catalog.suggestFromOcr("LECHE",p)==null;
        assert Catalog.findByBarcode("7801234567890",p)==null; // no fake barcode used
        assert Catalog.search("papel",p).size()==1;
        assert Catalog.demoQuotes(p.get(0)).size()==7;
        assert Catalog.demoQuotes(p.get(0)).get(0).priceClp<=Catalog.demoQuotes(p.get(0)).get(1).priceClp;
        assert "$1.250".equals(Catalog.clp(1250));
        List<Catalog.Quote> a=Arrays.asList(
           new Catalog.Quote("Líder","Santiago",1000,1,"USER_OBSERVED"),
           new Catalog.Quote("Líder","Santiago",900,2,"USER_OBSERVED"),
           new Catalog.Quote("Jumbo","Ñuñoa",850,3,"USER_OBSERVED"),
           new Catalog.Quote("Jumbo","Ñuñoa",800,9,"DEMO")
        );
        List<Catalog.Quote> latest=Catalog.newestPerStoreAndLocation(a);
        assert latest.size()==2;
        assert latest.get(0).priceClp==850;
        assert latest.get(1).priceClp==900;
        System.out.println("12 comprobaciones lógicas aprobadas: catálogo, OCR, código, orden, datos demo/manual.");
    }
}
