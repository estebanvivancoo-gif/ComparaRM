$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$jar = Join-Path $root 'gradle\wrapper\gradle-wrapper.jar'
$expected = '2db75c40782f5e8ba1fc278a5574bab070adccb2d21ca5a6e5ed840888448046'
if (Test-Path $jar) { exit 0 }
$tmp = "$jar.download"
try {
  Write-Output 'Descargando Gradle Wrapper oficial y verificando checksum SHA-256...'
  Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-8.11.1-wrapper.jar' -OutFile $tmp
  $actual = (Get-FileHash -Path $tmp -Algorithm SHA256).Hash.ToLowerInvariant()
  if ($actual -ne $expected) { throw 'Checksum del wrapper incorrecto: descarga rechazada.' }
  Move-Item -Path $tmp -Destination $jar
} finally { if (Test-Path $tmp) { Remove-Item $tmp -Force } }
