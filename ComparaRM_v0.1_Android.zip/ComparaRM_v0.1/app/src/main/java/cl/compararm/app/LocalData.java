package cl.compararm.app;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import cl.compararm.app.core.Catalog;

/** Local only: no internet requests. User-entered values are NOT verified. */
public final class LocalData {
    private final SharedPreferences prefs;
    LocalData(Context ctx) { prefs=ctx.getSharedPreferences("compararm_local_v1",Context.MODE_PRIVATE); }
    List<Catalog.Product> myProducts() {
        List<Catalog.Product> out=new ArrayList<>();
        try {
            JSONArray a=new JSONArray(prefs.getString("products","[]"));
            for(int i=0;i<a.length();i++) {
                JSONObject p=a.getJSONObject(i);
                out.add(new Catalog.Product(p.getString("id"),p.getString("name"),p.optString("units"),p.optString("ean"),false,new String[0],Collections.emptyMap()));
            }
        } catch (Exception ignored) { }
        return out;
    }
    void saveProduct(Catalog.Product product) {
        JSONArray a;
        try { a=new JSONArray(prefs.getString("products","[]")); }
        catch (Exception e) { a=new JSONArray(); }
        JSONObject p=new JSONObject();
        try {
            p.put("id",product.id); p.put("name",product.name);
            p.put("units",product.units); p.put("ean",product.ean);
            a.put(p); prefs.edit().putString("products",a.toString()).apply();
        } catch(Exception ignored) { }
    }
    List<Catalog.Quote> myQuotes(String productId) {
        List<Catalog.Quote> out=new ArrayList<>();
        try {
            JSONArray a=new JSONArray(prefs.getString("quotes","[]"));
            for(int i=0;i<a.length();i++) {
                JSONObject q=a.getJSONObject(i);
                if (!productId.equals(q.getString("productId"))) continue;
                out.add(new Catalog.Quote(q.getString("store"),q.getString("commune"),q.getInt("price"),q.getLong("time"),"USER_OBSERVED"));
            }
        } catch(Exception ignored) { }
        return Catalog.newestPerStoreAndLocation(out);
    }
    void saveQuote(String productId, Catalog.Quote quote) {
        try {
            JSONArray a=new JSONArray(prefs.getString("quotes","[]"));
            JSONObject q=new JSONObject();
            q.put("productId",productId);q.put("store",quote.store);
            q.put("commune",quote.commune);q.put("price",quote.priceClp);
            q.put("time",quote.observedAtMillis);q.put("origin","USER_OBSERVED");
            a.put(q); prefs.edit().putString("quotes",a.toString()).apply();
        } catch(Exception ignored) { }
    }
}
