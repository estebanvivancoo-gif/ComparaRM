package cl.compararm.app;

import android.content.ActivityNotFoundException;
import android.net.Uri;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.app.AlertDialog;
import android.text.InputType;
import android.util.TypedValue;

import androidx.activity.ComponentActivity;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.content.FileProvider;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.mlkit.vision.barcode.BarcodeScanning;
import com.google.mlkit.vision.barcode.BarcodeScanner;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import com.google.mlkit.vision.barcode.BarcodeScannerOptions;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

import cl.compararm.app.core.Catalog;

/** Native Android MVP. Image analysis runs on device; no retailer-network prices. */
public final class MainActivity extends ComponentActivity {
    private ScrollView page;
    private EditText searchInput;
    private TextView scanStatus, listCaption, selectedTitle, selectedSubtitle;
    private LinearLayout productList, selectedSection, demoPrices, manualPrices;
    private Catalog.Product selected;
    private LocalData localData;
    private List<Catalog.Product> allProducts;
    private String lastScannedCode="";
    private Uri photoUri;

    private final BarcodeScanner barcodeScanner=BarcodeScanning.getClient(
        new BarcodeScannerOptions.Builder().setBarcodeFormats(
            Barcode.FORMAT_EAN_13,Barcode.FORMAT_EAN_8,Barcode.FORMAT_UPC_A,Barcode.FORMAT_UPC_E
        ).build());
    private final TextRecognizer textRecognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);

    private final ActivityResultLauncher<Uri> cameraLauncher=registerForActivityResult(
        new ActivityResultContracts.TakePicture(), success -> {
            if (Boolean.TRUE.equals(success) && photoUri!=null) analyzePhoto(photoUri);
            else setStatus("No se tomó ninguna fotografía.");
        });
    private final ActivityResultLauncher<String> galleryLauncher=registerForActivityResult(
        new ActivityResultContracts.GetContent(), uri -> {
            if (uri!=null) analyzePhoto(uri);
        });

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        localData=new LocalData(this);
        page=findViewById(R.id.page);
        searchInput=findViewById(R.id.searchInput);
        scanStatus=findViewById(R.id.scanStatus);
        listCaption=findViewById(R.id.listCaption);
        productList=findViewById(R.id.productList);
        selectedSection=findViewById(R.id.selectedSection);
        selectedTitle=findViewById(R.id.selectedTitle);
        selectedSubtitle=findViewById(R.id.selectedSubtitle);
        demoPrices=findViewById(R.id.demoPrices);
        manualPrices=findViewById(R.id.manualPrices);
        if(savedInstanceState!=null) {
            String lastUri=savedInstanceState.getString("photoUri","");
            if(!lastUri.isEmpty()) photoUri=Uri.parse(lastUri);
            lastScannedCode=savedInstanceState.getString("lastCode","");
        }
        // Avoid content under Android 15+ system bars.
        ViewCompat.setOnApplyWindowInsetsListener(page,(view,insets)-> {
            Insets system=insets.getInsets(WindowInsetsCompat.Type.systemBars());
            view.setPadding(0,system.top,0,system.bottom);
            return insets;
        });
        reloadProducts();
        findViewById(R.id.cameraButton).setOnClickListener(v -> takePhoto());
        findViewById(R.id.galleryButton).setOnClickListener(v -> galleryLauncher.launch("image/*"));
        findViewById(R.id.searchButton).setOnClickListener(v -> searchAndRender());
        findViewById(R.id.addProductButton).setOnClickListener(v -> showAddProductDialog(lastScannedCode));
        findViewById(R.id.addPriceButton).setOnClickListener(v -> {
            if (selected != null && selected.example) showAddProductDialog(lastScannedCode);
            else showQuoteDialog();
        });
        searchInput.setOnEditorActionListener((v,actionId,event)-> {searchAndRender();return true;});
    }

    private void takePhoto() {
        try {
            File dir=new File(getCacheDir(),"camera_images");
            if (!dir.exists() && !dir.mkdirs()) { setStatus("No se pudo preparar la cámara."); return; }
            File f=File.createTempFile("producto_",".jpg",dir);
            photoUri=FileProvider.getUriForFile(this,getPackageName()+".fileprovider",f);
            cameraLauncher.launch(photoUri);
        } catch (ActivityNotFoundException e) {
            setStatus("No hay una aplicación de cámara disponible.");
        } catch (IOException e) {
            setStatus("No se pudo preparar la fotografía.");
        }
    }

    private void analyzePhoto(Uri uri) {
        setStatus("Analizando código de barras y texto de la foto…");
        try {
            InputImage input=InputImage.fromFilePath(this,uri);
            barcodeScanner.process(input)
                .addOnSuccessListener(codes -> {
                    String code="";
                    for(Barcode barcode:codes) {
                        if (barcode.getRawValue()!=null && !barcode.getRawValue().isEmpty()) {
                            code=barcode.getRawValue(); break;
                        }
                    }
                    final String detected=code;
                    textRecognizer.process(input)
                        .addOnSuccessListener(result -> handleDetection(detected,result.getText()))
                        .addOnFailureListener(err -> handleDetection(detected,""));
                })
                .addOnFailureListener(err -> textRecognizer.process(input)
                    .addOnSuccessListener(result -> handleDetection("",result.getText()))
                    .addOnFailureListener(ocrErr -> setStatus("No se pudo analizar la foto. Intenta nuevamente.")));
        } catch(Exception e) {
            setStatus("No se pudo abrir la imagen. Intenta otra fotografía.");
        }
    }

    private void handleDetection(String barcode,String recognizedText) {
        lastScannedCode=barcode==null?"":barcode.trim();
        Catalog.Product exact=Catalog.findByBarcode(lastScannedCode,allProducts);
        if (exact!=null) {
            setStatus("Código leído: "+lastScannedCode+". Encontrado en tus productos guardados.");
            showSelected(exact);
            return;
        }
        Catalog.Product proposed=Catalog.suggestFromOcr(recognizedText,allProducts);
        if(proposed!=null) {
            String prefix=lastScannedCode.isEmpty()?"":"Código leído: "+lastScannedCode+". ";
            setStatus(prefix+"Texto reconocido; categoría sugerida (NO se confirmó producto exacto). Revisa y corrige si es necesario.");
            showSelected(proposed);
            return;
        }
        if(!lastScannedCode.isEmpty()) {
            setStatus("Código leído: "+lastScannedCode+". Sin coincidencia en tu catálogo. Pulsa «Registrar producto propio» para asociarlo.");
            searchInput.setText(lastScannedCode);
        } else if (recognizedText!=null && !recognizedText.trim().isEmpty()) {
            String shortText=recognizedText.trim().replace('\n',' ');
            if (shortText.length()>100) shortText=shortText.substring(0,100)+"…";
            setStatus("Texto detectado: "+shortText+". No hay coincidencia segura; puedes buscar o registrar el producto.");
            searchInput.setText("");
        } else {
            setStatus("No se reconocieron códigos ni texto legible. Acerca el envase, mejora la luz o búscalo manualmente.");
        }
        selected=null;
        selectedSection.setVisibility(View.GONE);
        searchAndRender();
    }

    private void setStatus(String message) { scanStatus.setText(message); }
    private void reloadProducts() {
        allProducts=new ArrayList<>(Catalog.demoProducts());
        allProducts.addAll(localData.myProducts());
        renderList(allProducts);
    }
    private void searchAndRender() {
        List<Catalog.Product> result=Catalog.search(searchInput.getText().toString(),allProducts);
        renderList(result);
        if(result.isEmpty()) {
            listCaption.setText("No hay coincidencias. Puedes registrar un nuevo producto.");
        } else {
            listCaption.setText(result.size()+" resultado(s). Los productos de ejemplo no tienen identificación comercial validada.");
        }
    }
    private int px(float dp) { return (int)(dp*getResources().getDisplayMetrics().density+0.5f); }
    private GradientDrawable bg(int color,int stroke) {
        GradientDrawable shape=new GradientDrawable();shape.setColor(color);
        shape.setCornerRadius(px(11));
        shape.setStroke(px(1),stroke);return shape;
    }
    private TextView label(String title,int sp,boolean bold,int color) {
        TextView t=new TextView(this); t.setText(title);t.setTextColor(color);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP,sp);
        if(bold) t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        return t;
    }
    private void renderList(List<Catalog.Product> products) {
        productList.removeAllViews();
        if (products.isEmpty()) {
            TextView empty=label("No se encontraron productos en el catálogo local.",13,false,0xFF6D7D84);
            empty.setPadding(0,px(12),0,px(10));productList.addView(empty);
            return;
        }
        for (Catalog.Product p:products) {
            LinearLayout line=new LinearLayout(this);line.setOrientation(LinearLayout.VERTICAL);
            line.setPadding(px(13),px(11),px(13),px(11));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=px(7);
            line.setLayoutParams(lp);
            line.setBackground(bg(0xFFF8FAFB,0xFFE3EBEE));
            line.addView(label(p.name+" · "+p.units,15,true,0xFF183441));
            String desc=p.example?"CATÁLOGO DE DEMOSTRACIÓN · PRECIO FICTICIO":"AGREGADO POR TI · SIN PRECIO VALIDADO";
            TextView sub=label(desc,10,false,p.example?0xFF886018:0xFF06766F);
            sub.setPadding(0,px(4),0,0);line.addView(sub);
            line.setOnClickListener(v -> showSelected(p));
            productList.addView(line);
        }
    }
    private void showSelected(Catalog.Product p) {
        selected=p;
        selectedSection.setVisibility(View.VISIBLE);
        selectedTitle.setText(p.name+" · "+p.units);
        ((Button)findViewById(R.id.addPriceButton)).setText(p.example?
            "+ Crear producto exacto para registrar precio":"+ Registrar precio observado");
        selectedSubtitle.setText(p.example?
            "Categoría genérica de prueba. No equivale necesariamente al producto fotografiado.":
            "Producto personal"+(p.ean.isEmpty()?"":" · Código "+p.ean)+". Datos guardados solo en este teléfono.");
        demoPrices.removeAllViews();
        List<Catalog.Quote> demo=Catalog.demoQuotes(p);
        if(demo.isEmpty()) {
            emptyQuoteRow(demoPrices,"Este producto no tiene precios ficticios asociados.");
        } else {
            for (Catalog.Quote quote:demo) quoteRow(demoPrices,quote,Catalog.clp(quote.priceClp),"FICTICIO");
        }
        manualPrices.removeAllViews();
        List<Catalog.Quote> user=localData.myQuotes(p.id);
        if(user.isEmpty()) {
            emptyQuoteRow(manualPrices,"Aún no has registrado precios. Los valores que ingreses no estarán verificados.");
        } else {
            SimpleDateFormat date=new SimpleDateFormat("dd/MM/yyyy HH:mm",new Locale("es","CL"));
            for(Catalog.Quote quote:user) {
                quoteRow(manualPrices,quote,Catalog.clp(quote.priceClp),quote.commune+" · "+date.format(new Date(quote.observedAtMillis)));
            }
        }
        page.post(() -> page.smoothScrollTo(0,selectedSection.getTop()));
    }
    private void emptyQuoteRow(LinearLayout parent,String content) {
        TextView t=label(content,13,false,0xFF627681);
        t.setPadding(0,px(10),0,px(10));parent.addView(t);
    }
    private void quoteRow(LinearLayout parent,Catalog.Quote quote,String value,String detail) {
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(px(11),px(12),px(11),px(12));
        LinearLayout.LayoutParams layout=new LinearLayout.LayoutParams(-1,-2);layout.topMargin=px(5);
        row.setLayoutParams(layout);
        row.setBackground(bg(0xFFF8FAFB,0xFFE5ECEF));
        LinearLayout left=new LinearLayout(this);left.setOrientation(LinearLayout.VERTICAL);
        left.addView(label(quote.store,14,true,0xFF173441));
        TextView subtitle=label(detail,10,false,0xFF72848E);subtitle.setPadding(0,px(3),0,0);
        left.addView(subtitle);
        row.addView(left,new LinearLayout.LayoutParams(0,-2,1f));
        TextView right=label(value,17,true,quote.origin.equals("DEMO")?0xFF986014:0xFF087E7A);
        row.addView(right);
        parent.addView(row);
    }
    private EditText dialogText(String placeholder,String initial) {
        EditText input=new EditText(this);input.setSingleLine(true);
        input.setTextSize(TypedValue.COMPLEX_UNIT_SP,15);
        input.setHint(placeholder);input.setText(initial);
        return input;
    }
    private LinearLayout dialogColumn() {
        LinearLayout area=new LinearLayout(this);area.setOrientation(LinearLayout.VERTICAL);
        area.setPadding(px(22),px(10),px(22),px(8));return area;
    }
    private void showAddProductDialog(String barcode) {
        LinearLayout column=dialogColumn();
        TextView advice=label("Puedes asociar el código leído a un producto. No se descargarán precios automáticamente.",13,false,0xFF657781);
        column.addView(advice);
        EditText name=dialogText("Nombre del producto","");column.addView(name);
        EditText amount=dialogText("Presentación, ej. 900 ml","");column.addView(amount);
        EditText code=dialogText("Código de barras (opcional)",barcode==null?"":barcode);
        code.setInputType(InputType.TYPE_CLASS_NUMBER);column.addView(code);
        AlertDialog dialog=new AlertDialog.Builder(this)
            .setTitle("Registrar producto propio")
            .setView(column).setNegativeButton("Cancelar",(d,w)-> {})
            .setPositiveButton("Guardar",null).create();
        dialog.setOnShowListener(v -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(clicked -> {
            String n=name.getText().toString().trim();String u=amount.getText().toString().trim();
            String ean=code.getText().toString().trim();
            if(n.length()<3) {name.setError("Ingresa un nombre válido");return;}
            Catalog.Product dup=Catalog.findByBarcode(ean,allProducts);
            if(dup!=null) {code.setError("Código ya asociado a "+dup.name);return;}
            Catalog.Product product=new Catalog.Product("local-"+UUID.randomUUID(),n,u,ean,false,new String[0],java.util.Collections.emptyMap());
            localData.saveProduct(product);reloadProducts();searchInput.setText("");
            showSelected(product);dialog.dismiss();toast("Producto guardado en este dispositivo");
        }));
        dialog.show();
    }
    private void showQuoteDialog() {
        if (selected==null) {toast("Primero selecciona un producto.");return;}
        Catalog.Product current=selected;
        LinearLayout column=dialogColumn();
        column.addView(label("Registro personal sin verificación de la tienda. Indica el valor que ves en góndola o caja.",13,false,0xFF536D79));
        Spinner stores=new Spinner(this);
        ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,Catalog.STORES);
        stores.setAdapter(adapter);column.addView(stores);
        EditText comuna=dialogText("Comuna o sucursal (RM)","Santiago");column.addView(comuna);
        EditText price=dialogText("Precio CLP, solo números","");
        price.setInputType(InputType.TYPE_CLASS_NUMBER);column.addView(price);
        AlertDialog dialog=new AlertDialog.Builder(this)
            .setTitle("Registrar precio observado")
            .setView(column)
            .setNegativeButton("Cancelar",(d,w)-> {})
            .setPositiveButton("Guardar",null).create();
        dialog.setOnShowListener(v -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(clicked -> {
            String place=comuna.getText().toString().trim();
            String raw=price.getText().toString().replace(".","").replace("$","").trim();
            if(place.length()<3) {comuna.setError("Ingresa una ubicación");return;}
            int amount;
            try {amount=Integer.parseInt(raw);if(amount<=0 || amount>50_000_000) throw new NumberFormatException();}
            catch(NumberFormatException err) {price.setError("Ingresa un precio entero entre $1 y $50.000.000");return;}
            String store=stores.getSelectedItem().toString();
            localData.saveQuote(current.id,new Catalog.Quote(store,place,amount,System.currentTimeMillis(),"USER_OBSERVED"));
            showSelected(current);dialog.dismiss();toast("Observación local registrada, no verificada");
        }));
        dialog.show();
    }
    private void toast(String message) {Toast.makeText(this,message,Toast.LENGTH_LONG).show();}
    @Override protected void onSaveInstanceState(Bundle savedInstanceState) {
        if (photoUri!=null) savedInstanceState.putString("photoUri",photoUri.toString());
        savedInstanceState.putString("lastCode",lastScannedCode);
        super.onSaveInstanceState(savedInstanceState);
    }
    @Override protected void onDestroy() {
        barcodeScanner.close();textRecognizer.close();super.onDestroy();
    }
}
