package cl.compararm.app.core;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Pure-Java catalog/price logic; no assumption of live retailer access. */
public final class Catalog {
    private Catalog() { }
    public static final String[] STORES = {
        "Líder", "Jumbo", "Santa Isabel", "Unimarc", "Tottus", "aCuenta", "Mayorista 10"
    };

    public static final class Product {
        public final String id;
        public final String name;
        public final String units;
        public final String ean;
        public final boolean example;
        public final String[] keyWords;
        public final Map<String,Integer> demoPrices;
        public Product(String id, String name, String units, String ean, boolean example,
                       String[] keyWords, Map<String,Integer> demoPrices) {
            this.id=id; this.name=name; this.units=units; this.ean=ean;
            this.example=example; this.keyWords=keyWords; this.demoPrices=demoPrices;
        }
    }
    public static final class Quote {
        public final String store;
        public final String commune;
        public final int priceClp;
        public final long observedAtMillis;
        public final String origin; // DEMO or USER_OBSERVED. NEVER "VERIFIED" in this release.
        public Quote(String store, String commune, int priceClp, long observedAtMillis, String origin) {
            this.store=store; this.commune=commune; this.priceClp=priceClp;
            this.observedAtMillis=observedAtMillis; this.origin=origin;
        }
    }
    private static Product demo(String id,String name,String amount,String[] tokens,int... values) {
        Map<String,Integer> prices = new LinkedHashMap<>();
        for (int i=0;i<values.length;i++) prices.put(STORES[i],values[i]);
        return new Product(id,name,amount,"",true,tokens,prices);
    }
    public static List<Product> demoProducts() {
        List<Product> out=new ArrayList<>();
        // Fictitious figures used only to demonstrate sorting/display. Not retailer quotes.
        out.add(demo("demo-leche","Leche entera","1 L",new String[]{"LECHE","ENTERA"}, 1250,1390,1320,1350,1290,1240,1210));
        out.add(demo("demo-arroz","Arroz blanco","1 kg",new String[]{"ARROZ","BLANCO"}, 1690,1750,1590,1650,1720,1550,1490));
        out.add(demo("demo-fideos","Fideos spaghetti","400 g",new String[]{"SPAGHETTI","400"}, 980,1090,990,1050,970,940,920));
        out.add(demo("demo-aceite","Aceite vegetal","900 ml",new String[]{"ACEITE","900"}, 2390,2690,2490,2590,2450,2350,2250));
        out.add(demo("demo-azucar","Azúcar blanca","1 kg",new String[]{"AZUCAR","BLANCA"}, 1450,1490,1430,1480,1390,1360,1290));
        out.add(demo("demo-detergente","Detergente líquido","3 L",new String[]{"DETERGENTE","LIQUIDO"}, 8990,9490,9290,9150,8890,8590,8390));
        out.add(demo("demo-papel","Papel higiénico","4 rollos",new String[]{"PAPEL","HIGIENICO"}, 2590,2890,2750,2690,2790,2550,2490));
        out.add(demo("demo-yogurt","Yogurt natural","1 L",new String[]{"YOGURT","NATURAL"}, 1890,2050,1990,1950,1900,1750,1790));
        return out;
    }
    public static List<Quote> demoQuotes(Product product) {
        List<Quote> result=new ArrayList<>();
        if (!product.example) return result;
        for (Map.Entry<String,Integer> p:product.demoPrices.entrySet())
            result.add(new Quote(p.getKey(),"(ficticio)",p.getValue(),0L,"DEMO"));
        Collections.sort(result,Comparator.comparingInt(q -> q.priceClp));
        return result;
    }
    public static String normalize(String s) {
        if (s==null) return "";
        return Normalizer.normalize(s,Normalizer.Form.NFD).replaceAll("\\p{M}+","")
            .toUpperCase(Locale.ROOT).replaceAll("[^A-Z0-9]+"," ").trim();
    }
    public static Product suggestFromOcr(String ocr, List<Product> products) {
        String hay=" "+normalize(ocr)+" ";
        if (hay.trim().isEmpty()) return null;
        Product best=null; int bestScore=0;
        for (Product p: products) {
            if (p.keyWords.length<2) continue;
            int count=0;
            for (String keyword:p.keyWords) {
                if (hay.contains(" "+normalize(keyword)+" ")) count++;
            }
            if (count == p.keyWords.length && count>bestScore) { best=p; bestScore=count; }
        }
        return best; // ONLY a tentative category suggestion, never a verified SKU.
    }
    public static Product findByBarcode(String ean, List<Product> products) {
        if (ean==null || ean.trim().isEmpty()) return null;
        for (Product p:products) if (!p.ean.isEmpty() && ean.equals(p.ean)) return p;
        return null;
    }
    public static List<Product> search(String query,List<Product> products) {
        String needle=normalize(query); List<Product> found=new ArrayList<>();
        for (Product p: products) if (needle.isEmpty() || normalize(p.name+" "+p.units+" "+p.ean).contains(needle)) found.add(p);
        return found;
    }
    public static List<Quote> newestPerStoreAndLocation(List<Quote> all) {
        Map<String,Quote> chosen=new LinkedHashMap<>();
        for (Quote q:all) {
            if (!"USER_OBSERVED".equals(q.origin)) continue;
            String key=normalize(q.store+"|"+q.commune);
            Quote existing=chosen.get(key);
            if (existing==null || q.observedAtMillis>existing.observedAtMillis) chosen.put(key,q);
        }
        List<Quote> result=new ArrayList<>(chosen.values());
        result.sort(Comparator.comparingInt(q -> q.priceClp));
        return result;
    }
    public static String clp(int clp) {
        String raw=Integer.toString(clp); StringBuilder out=new StringBuilder("$");
        for (int i=0;i<raw.length();i++) {
            if (i>0 && (raw.length()-i)%3==0) out.append('.');
            out.append(raw.charAt(i));
        }
        return out.toString();
    }
}
