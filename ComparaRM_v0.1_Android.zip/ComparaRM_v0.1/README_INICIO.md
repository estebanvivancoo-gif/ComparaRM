# ComparaRM 0.1 · Android · Primera versión piloto

## Qué recibes

- `app/`: aplicación Android nativa (Java), con cámara del teléfono, imagen de galería, lectura de códigos EAN/UPC y reconocimiento de texto del envase con **ML Kit**.
- `preview/ComparaRM_demo.html`: **vista interactiva independiente** para probar la interfaz desde Chrome en Android, sin Android Studio. Permite buscar ejemplos, tomar fotografías, intentar leer códigos donde `BarcodeDetector` esté disponible y guardar registros propios. Esta vista **no tiene OCR**: el reconocimiento de texto está implementado en el proyecto Android nativo.
- `tests/`: pruebas automatizadas de la lógica del catálogo y separación de tipos de precio.
- `.github/workflows/android.yml`: flujo para generar un APK de depuración con GitHub Actions, si subes el proyecto a un repositorio propio.

## Estado real del proyecto

El proyecto contiene una **implementación de primera versión**, pero **NO se incluye un APK precompilado**. El entorno donde se preparó no dispone de Android SDK ni acceso para descargar las herramientas necesarias. **No se ha compilado ni probado en un teléfono Android**: se necesitan compilación y pruebas del dispositivo antes de usarla como app nativa. Sí se ejecutaron pruebas de Java puro para el catálogo, la búsqueda, la clasificación y el orden de precios.

No existe conexión a los sistemas de los supermercados. **No hay ningún precio de supermercado verificado** ni se promete actualización instantánea. En el código, los únicos tipos de cotización son `DEMO` y `USER_OBSERVED`.

## Probar ahora desde Android (sin instalar APK)

1. Descarga y descomprime el ZIP del proyecto.
2. Abre `preview/ComparaRM_demo.html` en Google Chrome del teléfono (desde tu gestor de archivos con «Abrir con Chrome», si está disponible).
3. Toca una categoría, compara la tabla de ejemplo y registra un precio manual.
4. Toca «Usar cámara» para intentar leer un código. La lectura web depende de compatibilidad del navegador y permisos. Cuando no funcione, usa la búsqueda/registro manual.

> La vista HTML es un archivo local de demostración, **no una app instalada desde Play Store**. El almacenamiento local puede no persistir con algunos visores de archivos. Usa «Exportar registros» para conservar una copia JSON de las observaciones.

## Compilar e instalar la aplicación Android (con computador)

1. Instala **Android Studio** desde `https://developer.android.com/studio`.
2. Descomprime este ZIP y en Android Studio selecciona **File > Open** y abre la carpeta `ComparaRM_v0.1`.
3. Usa **JDK 17**, Android SDK Platform 35 y conexión a Internet para que Android Studio descargue Gradle, ML Kit y AndroidX. Gradle 8.11.1, Android Gradle Plugin 8.9.2.
4. Espera a que termine **Sync Project with Gradle Files**. Si Android Studio pregunta por el SDK, instala **Android 15 / API 35**.
5. Conecta el teléfono Android por USB, activa **Opciones de desarrollador > Depuración USB** y presiona **Run (▶)** para instalar la app directamente; acepta el aviso de autorización en el teléfono.
6. Si prefieres un archivo APK, selecciona **Build > Build Bundle(s) / APK(s) > Build APK(s)**. El resultado de depuración suele quedar en `app/build/outputs/apk/debug/app-debug.apk`. Transfiérelo a tu Android y ábrelo desde Archivos; Android puede solicitar permiso para «Instalar aplicaciones desconocidas» desde ese origen. Autorízalo solo si tú mismo compilaste y confías en el proyecto.

También puedes generar el APK por GitHub Actions: crea un repositorio privado, sube el contenido completo, abre **Actions > Compilar APK Android (sin publicar) > Run workflow** y descarga el artefacto `ComparaRM-debug-apk`. Un APK de depuración es para pruebas, no para Play Store ni distribución pública.

**Nota sobre Gradle:** los archivos `gradlew`/`gradlew.bat` descargan el JAR **oficial** del Gradle Wrapper al primer uso y validan su checksum SHA-256, ya que en este entorno no se pudo obtener el binario. La distribución Gradle también está fijada por checksum. Si la red de tu equipo bloquea `services.gradle.org`, deberás configurar Gradle 8.11.1 desde Android Studio o una red autorizada.

## Uso de la app Android

1. **Abrir cámara**: se abre la cámara del sistema (no se solicita permiso de cámara a ComparaRM). Fotografía el código EAN/UPC o el texto del envase. La app analiza la foto en el equipo mediante modelos ML Kit incluidos.
2. **Código detectado que ya guardaste**: abre el producto propio por coincidencia exacta.
3. **Texto detectado**: cuando se encuentran las palabras de una categoría de ejemplo, se propone una coincidencia **tentativa**, nunca una identificación de SKU verificada. Corrige o agrega un producto propio con la presentación exacta.
4. **Sin coincidencia**: pulsa **Registrar producto propio** y escribe nombre y presentación; el último código detectado se incorpora al formulario.
5. **Comparación**: los datos simulados aparecen separados de tus observaciones manuales. Para registrar una observación debes **crear un producto propio con nombre y presentación exactos** (no se aceptan registros en categorías ficticias); después escoge tienda, comuna/sucursal y monto.
6. Todos los registros se guardan con fecha/hora en almacenamiento privado de la app. No se envían fotos ni datos a servidores; el manifest ni siquiera solicita el permiso `INTERNET`.

## Fuentes, limitaciones y criterios

- `DEMO`: montos **inventados expresamente para pruebas**, no son consultas a supermercados ni estadísticas ni promedios; no deben usarse para comprar.
- `USER_OBSERVED`: monto ingresado por la persona; **no verificado de forma independiente**. Representa una observación puntual y puede no estar actualizado.
- `VERIFIED`: **no existe en la versión 0.1**. Para implementarlo se necesitaría origen oficial o autorizado, SKU/EAN exacto, variante/unidad, ubicación, fecha/hora de consulta y condiciones de precio (tarjeta, cupón, límite de unidades).
- Las categorías demo (leche 1 L, arroz 1 kg, etc.) no representan el mismo producto de distintas marcas. Nunca deben convertirse automáticamente en una comparación real por SKU.
- Una versión histórica indexada del Observatorio de Precios de SERNAC indicaba que no mostraba precios individuales. Como el enlace actualmente puede redirigir y no se dispone de una API pública confirmada para esta finalidad, **no se utiliza como fuente**. No puedo confirmar que exista una interfaz vigente de precios individuales.
- Cobertura conceptual Santiago/Región Metropolitana; la app no utiliza geolocalización automática (el usuario escribe la comuna o sucursal). Los siete nombres de cadenas representan objetivos, no integraciones disponibles.
- Esta versión usa **captura de foto** con la app de cámara; todavía no hay reconocimiento continuo en video, ni OCR universal de cualquier etiqueta o logo, ni IA entrenada para reconocer el aspecto visual del producto.

## Siguiente etapa técnica para precios reales

Servidor HTTPS seguro y normalización de catálogo: identificador EAN/GTIN; marca, tamaño y variedad exactos; asignación de cadena/sucursal o zona; conector autorizado por cada retailer; caché con hora de consulta; estado `DISPONIBLE`, `DESACTUALIZADO` o `SIN_DATOS`; costos condicionados separados de precio normal; tratamiento de productos sin coincidencia evitando comparaciones engañosas. No usar raspado masivo sin revisar términos de servicio, datos y normativas aplicables.

## Datos personales y privacidad

Este prototipo no pide ubicación, cuentas, contactos ni internet. Los registros quedan en `SharedPreferences` privado del teléfono y se eliminan al desinstalar la app (salvo respaldos fuera de la app). Las fotos temporales tomadas con cámara se guardan en caché de la aplicación, y las imágenes seleccionadas desde galería se leen con permisos temporales. No está pensado aún para tratamiento de datos personales a escala ni publicación en producción.

## Documentación oficial para revisar versiones y funcionamiento

- ML Kit Barcode Scanning: https://developers.google.com/ml-kit/vision/barcode-scanning/android
- ML Kit Text Recognition: https://developers.google.com/ml-kit/vision/text-recognition/v2/android
- Android Gradle Plugin 8.9: https://developer.android.com/build/releases/agp-8-9-0-release-notes
- Android Studio: https://developer.android.com/studio
- Checksums de Gradle 8.11.1: https://gradle.org/release-checksums/
- Observatorio de Precios SERNAC: https://www.sernac.cl/observatorio/
